# Classic Point & Click Adventure Engine

This is the **clean, game-independent engine** extracted from the final browser version of *Escape From Dinosaur Island*.

The important design goal is separation:

- `js/engine.js` contains **engine behavior only**.
- `js/game.js` contains **your game's content only**.
- `css/engine.css` contains the preserved interface layout and styling.
- `assets/ui/` contains the exact GO / EXAMINE / TAKE / OPERATE and N / E / S / W interface icons used by the final build.

There are **no Dinosaur Island scenes, puzzles, dialogue, item art, passwords, characters, music, sound effects, or story content** in the raw engine.

The gameplay UI deliberately keeps the same layout: the viewing window, four action buttons, four compass buttons, black message window, action-status strip, and six inventory windows.

---

## 1. The simplest mental model

A point-and-click adventure built with this engine has four layers:

1. **Scene** — where the player currently is.
2. **Hotspots** — invisible clickable rectangles over things in the scene picture.
3. **State** — facts the game remembers, such as `doorOpen: true`.
4. **Actions** — what happens when the player EXAMINES, TAKES, OPERATES, or moves.

The engine handles the interface and plumbing. You describe the game in `js/game.js`.

---

## 2. Folder map

```text
classic_point_click_engine/
├── index.html
├── README.md
├── css/
│   └── engine.css
├── js/
│   ├── game.js        <-- START HERE
│   └── engine.js      <-- reusable engine; usually leave alone
├── assets/
│   └── ui/
│       ├── go.png
│       ├── examine.png
│       ├── take.png
│       ├── operate.png
│       ├── north.png
│       ├── east.png
│       ├── south.png
│       └── west.png
└── docs/
    ├── TUTORIAL.md
    └── ENGINE_API.md
```

Open `index.html` directly in a browser. The starter works without a web server.

---

## 3. Make your first real scene

Put an image somewhere in the project, for example:

```text
assets/scenes/bedroom.png
```

Then edit the starter scene in `js/game.js`:

```js
start: {
  title: "Bedroom",
  image: "assets/scenes/bedroom.png",
  description: "You wake up in a quiet bedroom.",
  exits: {},
  hotspots: []
}
```

Reload the page. That is already a valid one-room adventure.

---

## 4. Add another room and connect it

```js
scenes: {
  bedroom: {
    title: "Bedroom",
    image: "assets/scenes/bedroom.png",
    description: "You are in the bedroom.",
    exits: {
      east: "hallway"
    },
    hotspots: []
  },

  hallway: {
    title: "Hallway",
    image: "assets/scenes/hallway.png",
    description: "A narrow hallway stretches ahead.",
    exits: {
      west: "bedroom"
    },
    hotspots: []
  }
}
```

Also change:

```js
startScene: "bedroom"
```

Now the player can press **GO**, then **E**, to enter the hallway, and **GO**, then **W**, to return.

If a direction is missing from `exits`, the engine says:

> You can't go that way.

---

## 5. Hotspots: the core of the game

A hotspot is an invisible rectangle on top of the scene picture.

All hotspot coordinates are percentages of the **actual picture**, not percentages of the browser window.

```js
hotspots: [
  {
    id: "painting",
    x: 10,
    y: 20,
    w: 25,
    h: 30,
    examine: "An old landscape painting."
  }
]
```

That means:

- `x: 10` — starts 10% from the left
- `y: 20` — starts 20% from the top
- `w: 25` — is 25% of the picture width
- `h: 30` — is 30% of the picture height

Select **EXAMINE**, click that rectangle, and the message appears in the black text window.

### Overlapping hotspots

Hotspots are checked **from the bottom of the array upward**. In other words, a hotspot defined later wins if two overlap.

This is useful when you have a giant wall hotspot with a tiny sign sitting on it:

```js
hotspots: [
  { id: "wall", x: 0, y: 0, w: 100, h: 100, examine: "A concrete wall." },
  { id: "sign", x: 40, y: 20, w: 12, h: 8, examine: "AUTHORIZED PERSONNEL ONLY" }
]
```

The small sign gets priority.

---

## 6. Debug mode: see your hotspots

Add this to the end of the page address:

```text
?debug=1
```

For example:

```text
index.html?debug=1
```

Every hotspot is drawn as a magenta rectangle with its `id` inside.

This is one of the most useful features in the entire engine.

The engine includes the corrected **object-fit / letterboxing math** from the final game, so the debug rectangles and click coordinates stay attached to the visible image even when the browser resizes it.

---

## 7. Measuring hotspots in pixels instead of percentages

Percentages are great for storage but annoying to calculate by hand.

The engine includes:

```js
engine.rectFromPixels(...)
```

Suppose your original scene image is 640 × 480 and the door occupies pixels `(100, 50)` through `(220, 180)`.

```js
hotspots: [
  Engine.rectFromPixels(
    640, 480,
    100, 50,
    220, 180,
    {
      id: "door",
      examine: "A heavy wooden door."
    }
  )
]
```

However, `Engine` is created after `game.js` loads, so for top-level static scene data use a function:

```js
hotspots: ({ engine }) => [
  engine.rectFromPixels(640, 480, 100, 50, 220, 180, {
    id: "door",
    examine: "A heavy wooden door."
  })
]
```

That is usually the easiest way to transfer coordinates from an image editor.

---

## 8. Examine, take, and operate

A hotspot can react differently to each action.

```js
{
  id: "desk",
  x: 20, y: 30, w: 40, h: 30,

  examine: "A battered wooden desk.",

  take: "The desk is much too heavy.",

  operate: "You open and close a drawer."
}
```

Those properties can be plain strings **or functions**.

Functions are how you make puzzles.

```js
operate({ state }) {
  state.flags.drawerOpen = true;
  return "You open the drawer.";
}
```

The object passed into the function contains useful things such as:

```js
{
  engine,
  state,
  sceneId,
  scene,
  selectedItem,
  hotspot,
  itemId
}
```

You do not need to memorize that. `docs/ENGINE_API.md` has the full list.

---

## 9. Game state / puzzle flags

A game needs to remember what the player has done.

Put your flags in `createState()`:

```js
createState() {
  return {
    flags: {
      drawerOpen: false,
      powerOn: true,
      monsterGone: false
    }
  };
}
```

Then a hotspot can change them:

```js
operate({ state }) {
  state.flags.drawerOpen = true;
  return "You open the drawer.";
}
```

And another hotspot can read them:

```js
examine({ state }) {
  return state.flags.drawerOpen
    ? "The drawer is open."
    : "The drawer is closed.";
}
```

State is reset automatically whenever a new game begins.

---

## 10. Conditional scene pictures

A scene's `image` can be a function.

```js
image({ state }) {
  return state.flags.drawerOpen
    ? "assets/scenes/desk_open.png"
    : "assets/scenes/desk_closed.png";
}
```

Whenever the state changes, call:

```js
engine.renderScene();
```

Example:

```js
operate({ engine, state }) {
  state.flags.drawerOpen = true;
  engine.renderScene();
  return "You open the drawer.";
}
```

This is how the original project swapped glove-box, filing-cabinet, fence, character, and other visual states without needing a different engine.

---

## 11. Inventory: exactly six windows

The UI intentionally always draws exactly **six inventory windows**.

Define up to six items in `GAME.items`:

```js
items: {
  key: {
    name: "Key",
    icon: "assets/items/key.png",
    examine: "A small brass key."
  },

  flashlight: {
    name: "Flashlight",
    icon: "assets/items/flashlight.png",
    examine: "A pocket flashlight."
  }
}
```

If the player does not own an item, its window is **completely empty**. There is no blurred silhouette or hidden label.

Give the player an item from a hotspot:

```js
take({ engine }) {
  return engine.takeItem("key", "You took the key.");
}
```

Remove or consume it:

```js
engine.removeItem("key");
```

Check whether it is owned:

```js
if (engine.hasItem("key")) {
  // ...
}
```

---

## 12. OPERATE an item on a scene object

When the player clicks **OPERATE**, then an inventory item, that item's slot becomes selected.

When the player then clicks a hotspot, the hotspot's `operate()` function receives `itemId`:

```js
{
  id: "lockedDoor",
  x: 60, y: 10, w: 25, h: 80,

  examine({ state }) {
    return state.flags.doorOpen
      ? "The door is open."
      : "The door is locked.";
  },

  operate({ engine, state, itemId }) {
    if (itemId === "key") {
      state.flags.doorOpen = true;
      engine.removeItem("key");
      engine.renderScene();
      return "The key turns. The door opens.";
    }

    return "That doesn't work.";
  }
}
```

That is the basic pattern behind most inventory puzzles.

---

## 13. Item-on-item combinations

For something like **matches + torch**, use `itemCombinations`:

```js
itemCombinations: [
  {
    items: ["matches", "torch"],

    action({ state }) {
      state.flags.torchLit = true;
      return "You light the torch.";
    }
  }
]
```

The order does not matter. Matches on torch and torch on matches both match that combination.

If no combination exists, the engine says:

> Nothing happened.

---

## 14. Conditional movement

For a simple exit:

```js
north: "hallway"
```

For a locked or dangerous exit, use a function:

```js
north({ engine, state }) {
  if (state.flags.doorOpen) {
    engine.goTo("hallway");
  } else {
    return "The door is locked.";
  }
}
```

For a deadly route:

```js
west({ engine }) {
  engine.die("You walk directly into the monster.");
}
```

For a route that requires an item:

```js
west({ engine }) {
  if (engine.hasItem("disguise")) {
    engine.goTo("guardPost");
  } else {
    engine.die("The guard spots you immediately.");
  }
}
```

---

## 15. Game over

Anywhere in a handler:

```js
engine.die("You fall into the pit.");
```

The engine switches to the Game Over screen and shows the message.

**TRY AGAIN** creates a completely fresh state and restarts the timer.

---

## 16. Winning

Anywhere in a handler:

```js
engine.win();
```

Or supply a custom heading:

```js
engine.win("You escaped! Congratulations!");
```

The hidden timer stops immediately when `win()` is called and becomes visible on the victory screen.

---

## 17. Text-entry puzzles / passwords

The raw engine includes a generic version of the text terminal system.

```js
operate({ engine, state }) {
  engine.openTextPrompt({
    body: "SECURITY TERMINAL\n\nPassword:",

    onSubmit(value) {
      if (value === "1234") {
        state.flags.securityOff = true;
        return "ACCESS GRANTED";
      }

      return "ACCESS DENIED";
    }
  });

  return "";
}
```

You can use that for:

- passwords
- PIN codes
- name entry
- computer terminals
- riddles
- keypad puzzles
- combination locks

It is not tied to any particular game.

---

## 18. Music and victory sounds

In `game.js`:

```js
music: "assets/audio/music.ogg",
victorySound: "assets/audio/victory.wav",
musicVolume: 0.30,
```

The existing **MUSIC: ON** button handles play/pause.

Leave the strings empty for a silent game.

---

## 19. Keeping everything in one HTML file later

The source edition is split into files because it is dramatically easier to read and edit.

Nothing prevents you from packaging a finished game into one HTML file later:

- CSS can be inserted into `<style>`.
- JavaScript can be inserted into `<script>`.
- PNG/audio files can be converted to `data:` URLs.

That is exactly how a complete game can become one portable HTML file.

Do development in the clean multi-file version. Package it only when you are ready to distribute.

---

## 20. Why `getVisibleSceneRect()` matters

This deserves its own explanation because it fixes a subtle bug that is easy to reintroduce.

The scene image uses:

```css
object-fit: contain;
```

If the shape of the browser window does not exactly match the scene image, the browser may place black empty space around the picture.

The `<img>` HTML element can therefore be wider or taller than the painted picture inside it.

If hotspot math uses the HTML element's full rectangle, clicking slowly drifts away from the intended object.

`getVisibleSceneRect()` calculates the actual painted image rectangle first. Both normal click detection and the debug overlay use that corrected rectangle.

**Do not simplify it back to `sceneImage.getBoundingClientRect()` unless you remove object-fit letterboxing entirely.**

---

## 21. What belongs in engine.js vs game.js?

Put it in **game.js** when it is specific to your adventure:

- room names
- scene art
- descriptions
- characters
- dialogue
- puzzles
- passwords
- inventory items
- item art
- which directions connect rooms
- death descriptions
- story text

Put it in **engine.js** when it changes the behavior of every game:

- add a fifth action verb
- change how hotspots are selected
- change how inventory selection works
- add save/load support
- add touch gestures
- change the timer system
- change the number of inventory windows
- add animation support

That separation is the whole reason this raw edition exists.

---

## 22. Common beginner mistakes

### "My hotspot is in the wrong place"

Use `?debug=1`. Check that `x`, `y`, `w`, and `h` are percentages, or use `rectFromPixels()`.

### "My scene function changed state but the picture did not change"

Call:

```js
engine.renderScene();
```

### "My item never appears"

First define it in `GAME.items`, then call:

```js
engine.takeItem("yourItemId");
```

### "My inventory has seven items"

This UI is intentionally fixed at six item windows. The engine throws an error if `GAME.items` defines more than six.

### "I clicked north and nothing happened"

The player must click **GO** before a direction. That behavior is intentional.

### "I put an exit to a scene that doesn't exist"

The engine throws a readable error in the browser console instead of silently failing.

### "My text prompt doesn't close"

Return from `onSubmit`; the engine closes the prompt automatically after submission.

---

## 23. Recommended way to build a game

A clean workflow is:

1. Create all scene images.
2. Put scene entries in `GAME.scenes` with no hotspots.
3. Connect the map using `exits`.
4. Test the entire map.
5. Add EXAMINE hotspots.
6. Add TAKE items.
7. Add puzzle state flags.
8. Add OPERATE logic.
9. Add deaths and special cases.
10. Test with `?debug=1`.
11. Add music/title/story/about polish last.

This keeps navigation bugs separate from puzzle bugs.

---

## 24. The raw engine is intentionally boring

That is a feature.

An engine should not know that your game has a dinosaur, spaceship, haunted hotel, detective, pirate ship, or anything else. It should know only how to:

- show a scene
- detect clicks
- remember state
- move between scenes
- manage inventory
- dispatch actions
- display messages

Everything interesting belongs to the game you build on top of it.
