These eight PNG files are byte-for-byte extractions of the action and direction icons used by the final V50 interface.
They are kept separate from game content because they are part of the preserved UI.
