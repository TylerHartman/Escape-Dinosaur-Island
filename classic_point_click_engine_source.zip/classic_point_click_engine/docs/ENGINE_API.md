# Engine API Reference

This file is the compact reference for functions exposed as `engine` inside game handlers and as the global `Engine` object in the browser console.

## Handler context

A hotspot function typically looks like:

```js
operate({ engine, state, itemId, hotspot, sceneId, scene }) {
  // ...
}
```

Available context fields depend on the event, but the common fields are:

- `engine` — the public engine API described below.
- `state` — the live current game state.
- `sceneId` — current scene ID string.
- `scene` — current scene definition object.
- `selectedItem` — currently selected inventory item ID, or `null`.
- `itemId` — selected item ID when operating on a hotspot.
- `hotspot` — the clicked hotspot.
- `direction` — on conditional exit functions.
- `firstItemId` / `secondItemId` — in item combinations.
- `value` — in text-prompt callbacks.

## `engine.say(text)`

Write text to the black message window.

```js
engine.say("Hello.");
```

Normally you can simply `return "Hello."` from a hotspot instead.

## `engine.goTo(sceneId, message?)`

Move to another scene.

```js
engine.goTo("kitchen");
```

Uses the destination scene's `description` automatically.

Optional custom arrival text:

```js
engine.goTo("kitchen", "You squeeze through the narrow doorway.");
```

## `engine.takeItem(id, message?)`

Mark an item as owned and redraw inventory.

```js
return engine.takeItem("key", "You took the key.");
```

The item must already exist in `GAME.items`.

## `engine.removeItem(id)`

Remove/consume an item.

```js
engine.removeItem("key");
```

## `engine.hasItem(id)`

Returns `true` or `false`.

```js
if (engine.hasItem("key")) {
  // ...
}
```

## `engine.die(message)`

Immediately show the Game Over screen.

```js
engine.die("The bridge collapses beneath you.");
```

## `engine.win(message?)`

Stop the hidden timer and show the victory screen.

```js
engine.win();
```

Or:

```js
engine.win("You escaped!");
```

## `engine.renderScene()`

Re-evaluate the current scene's image and hotspots.

Call this after changing a flag that affects visible scene state.

```js
state.flags.drawerOpen = true;
engine.renderScene();
```

## `engine.renderInventory()`

Force an inventory redraw. Usually `takeItem()` and `removeItem()` do this for you.

## `engine.clearAction()`

Return the action bar to `Choose an action.` and deselect an inventory item.

The engine normally does this automatically after an action.

## `engine.openTextPrompt(options)`

Open the reusable terminal/text-entry modal.

```js
engine.openTextPrompt({
  body: "ENTER PASSWORD:",
  placeholder: "password",
  selectText: true,

  onSubmit(value, context) {
    return value === "secret" ? "Correct." : "Wrong.";
  },

  onCancel(context) {
    return "You step away from the terminal.";
  }
});
```

Options:

- `body` — text shown above the input.
- `value` — initial input value.
- `placeholder` — HTML input placeholder.
- `selectText` — if true, select the initial value on open.
- `onSubmit(value, context)` — callback after ENTER.
- `onCancel(context)` — callback after CANCEL or Escape.

## `engine.closeTextPrompt()`

Close the prompt programmatically.

## `engine.rectFromPixels(imageWidth, imageHeight, x1, y1, x2, y2, extra?)`

Convert pixel coordinates into a hotspot object using percentages.

```js
hotspots: ({ engine }) => [
  engine.rectFromPixels(640, 480, 100, 50, 220, 180, {
    id: "door",
    examine: "A door."
  })
]
```

## `engine.getState()`

Get the live state object.

```js
const state = engine.getState();
state.flags.powerOn = false;
```

Inside normal game handlers you already receive `state`, so this is most useful in the browser console or in helper functions.

## `engine.getGame()`

Returns the complete `GAME` definition.

## `engine.isDebugMode()`

Returns whether the page was opened with `?debug=1`.

---

# Scene reference

```js
someScene: {
  title: "Scene Title",
  image: "assets/scenes/file.png",
  description: "Arrival text.",
  exits: {
    north: "otherScene",
    east({ engine, state }) { /* conditional movement */ }
  },
  hotspots: [ /* hotspot objects */ ]
}
```

`title`, `image`, `description`, and `hotspots` may be functions. Functions receive the standard context.

# Hotspot reference

```js
{
  id: "uniqueName",
  x: 10,
  y: 20,
  w: 30,
  h: 40,
  examine: "Text or function",
  take: "Text or function",
  operate: "Text or function"
}
```

Coordinates are percentages of the visible scene image.

# Item reference

```js
key: {
  name: "Key",
  icon: "assets/items/key.png",
  examine: "A small brass key."
}
```

`icon` and `examine` may also be functions.

# State reference

Engine-owned fields:

```js
state.scene
state.verb
state.selectedItem
state.inventory
state.dead
state.won
```

Recommended custom state:

```js
state.flags.yourFlag
```

Avoid repurposing engine-owned fields unless you intentionally change engine behavior.
