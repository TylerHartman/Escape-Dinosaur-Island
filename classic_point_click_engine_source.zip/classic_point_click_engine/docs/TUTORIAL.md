# Beginner Tutorial — Build a Tiny Adventure From Scratch

This tutorial assumes you have never written a point-and-click game before.

You will build a tiny two-room game with one key and one locked door. The goal is not to make something impressive; it is to show how every major part of the engine fits together.

## Step 1 — Make folders for your art

Inside the engine folder create:

```text
assets/scenes/
assets/items/
```

Put two 640×480 images in `assets/scenes/`:

```text
room.png
hallway.png
```

Put one small transparent PNG in `assets/items/`:

```text
key.png
```

Any reasonable image size works. 640×480 is just convenient for this example.

## Step 2 — Define the item

In `js/game.js`, replace `items: {}` with:

```js
items: {
  key: {
    name: "Key",
    icon: "assets/items/key.png",
    examine: "A small brass key."
  }
},
```

The item now exists in the game's vocabulary, but the player does not own it yet.

## Step 3 — Add state flags

Replace `createState()` with:

```js
createState() {
  return {
    flags: {
      keyTaken: false,
      doorOpen: false
    }
  };
},
```

These booleans are the game's memory.

## Step 4 — Build the first room

Replace the starter scene with:

```js
room: {
  title: "Room",
  image: "assets/scenes/room.png",
  description: "You are standing in a small room.",
  exits: {
    east({ engine, state }) {
      if (state.flags.doorOpen) {
        engine.goTo("hallway");
      } else {
        return "The door is locked.";
      }
    }
  },
  hotspots: ({ engine, state }) => [
    engine.rectFromPixels(640, 480, 80, 300, 140, 360, {
      id: "key",
      examine: state.flags.keyTaken ? "Nothing unusual here." : "A key is lying on the floor.",
      take() {
        if (state.flags.keyTaken) return "You already took it.";
        state.flags.keyTaken = true;
        return engine.takeItem("key", "You took the key.");
      }
    }),

    engine.rectFromPixels(640, 480, 500, 80, 630, 450, {
      id: "door",
      examine() {
        return state.flags.doorOpen ? "The door is open." : "The door is locked.";
      },
      operate({ itemId }) {
        if (state.flags.doorOpen) return "The door is already open.";
        if (itemId !== "key") return "That doesn't unlock it.";

        state.flags.doorOpen = true;
        engine.removeItem("key");
        engine.renderScene();
        return "The key turns. The door opens.";
      }
    })
  ]
}
```

Then set:

```js
startScene: "room",
```

## Step 5 — Add the hallway

Add this next to `room`:

```js
hallway: {
  title: "Hallway",
  image: "assets/scenes/hallway.png",
  description: "You made it into the hallway.",
  exits: {
    west: "room"
  },
  hotspots: [
    {
      id: "exit",
      x: 30,
      y: 20,
      w: 40,
      h: 60,
      examine: "Freedom is just ahead.",
      operate({ engine }) {
        engine.win("You escaped the tutorial!");
        return "";
      }
    }
  ]
}
```

## Step 6 — Run it

Open `index.html`.

The complete puzzle loop is now:

1. EXAMINE the key.
2. TAKE the key.
3. OPERATE.
4. Click the key in inventory.
5. Click the door.
6. GO → E.
7. OPERATE the exit.
8. Win.

## Step 7 — Turn on debug rectangles

Open:

```text
index.html?debug=1
```

Adjust the pixel rectangles until they sit precisely over your artwork.

## Step 8 — Why the hotspots are functions

You may have noticed:

```js
hotspots: ({ engine, state }) => [ ... ]
```

instead of:

```js
hotspots: [ ... ]
```

Both are legal.

Use a plain array when the hotspot never changes.
Use a function when its text, location, or existence depends on state.

Because the function runs again whenever `engine.renderScene()` is called, it can rebuild the hotspot list using the latest game state.

## Step 9 — Next things to try

Try adding one at a time:

- a second inventory item
- a fatal hotspot using `engine.die()`
- a scene image that changes after a flag flips
- a password terminal using `engine.openTextPrompt()`
- an item combination in `itemCombinations`
- music in `GAME.music`

Once those make sense, you understand almost the whole engine.
