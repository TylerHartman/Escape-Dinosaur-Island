"use strict";

/*
===============================================================================
CLASSIC POINT & CLICK ADVENTURE ENGINE
===============================================================================

PURPOSE
-------
This file is the reusable ENGINE. It contains no Dinosaur Island scenes,
dialogue, puzzles, inventory items, or story data.

The engine handles the mechanical jobs that almost every game using this UI
needs:

  1. Showing scenes and scene titles.
  2. Converting clicks on a scaled/letterboxed image into hotspot coordinates.
  3. GO / EXAMINE / TAKE / OPERATE action selection.
  4. North / East / South / West movement.
  5. Six inventory slots and item selection.
  6. Item-on-item combinations.
  7. Game state / puzzle flags.
  8. Game over and victory screens.
  9. A hidden run timer that appears on victory.
 10. Optional looping music and a victory sound.
 11. A reusable text-entry modal for passwords, terminals, riddles, etc.
 12. ?debug=1 hotspot visualization.

BEGINNER RULE OF THUMB
----------------------
If you are making a game, edit js/game.js first.
Only edit this file when you want to change how the ENGINE itself behaves.
===============================================================================
*/

(function () {
  /* ----------------------------------------------------------------------- */
  /* 1. SMALL DOM HELPER                                                      */
  /* ----------------------------------------------------------------------- */

  // $("#thing") is simply shorter than document.querySelector("#thing").
  function $(selector) {
    return document.querySelector(selector);
  }

  /* ----------------------------------------------------------------------- */
  /* 2. GET REFERENCES TO THE EXISTING UI                                    */
  /* ----------------------------------------------------------------------- */

  // Keeping all element lookups together makes the rest of the file easier to
  // read. These IDs correspond directly to elements in index.html.
  const ui = {
    startScreen: $("#start-screen"),
    gameScreen: $("#game-screen"),
    gameOverScreen: $("#game-over-screen"),
    winScreen: $("#win-screen"),

    titleArt: $("#title-art"),
    startNote1: $("#start-note-1"),
    startNote2: $("#start-note-2"),

    sceneTitle: $("#scene-title"),
    sceneWrap: $("#scene-wrap"),
    sceneImage: $("#scene-image"),
    debugOverlay: $("#debug-overlay"),

    message: $("#message"),
    actionStatus: $("#action-status"),
    inventory: $("#inventory"),
    buildLabel: $("#build-label"),

    musicButton: $("#music-toggle"),
    music: $("#music"),
    victorySound: $("#victory-sound"),

    gameOverImage: $("#game-over-image"),
    deathMessage: $("#death-message"),

    winImage: $("#win-image"),
    winHeading: $("#win-heading"),
    winSubtitle: $("#win-subtitle"),
    escapeTime: $("#escape-time"),

    helpModal: $("#help-modal"),
    storyModal: $("#story-modal"),
    aboutModal: $("#about-modal"),
    instructionsContent: $("#instructions-content"),
    storyContent: $("#story-content"),
    aboutContent: $("#about-content"),

    promptModal: $("#text-prompt-modal"),
    promptBody: $("#text-prompt-body"),
    promptInput: $("#text-prompt-input"),
    promptSubmit: $("#text-prompt-submit"),
    promptCancel: $("#text-prompt-cancel")
  };

  /* ----------------------------------------------------------------------- */
  /* 3. VALIDATE THE GAME FILE                                               */
  /* ----------------------------------------------------------------------- */

  const game = window.GAME;

  if (!game || typeof game !== "object") {
    throw new Error("GAME was not found. Make sure js/game.js loads before js/engine.js.");
  }

  if (!game.scenes || typeof game.scenes !== "object") {
    throw new Error("GAME.scenes is missing. Define at least one scene in js/game.js.");
  }

  if (!game.startScene || !game.scenes[game.startScene]) {
    throw new Error("GAME.startScene must name a scene that exists in GAME.scenes.");
  }

  const itemDefinitions = game.items || {};
  const itemIds = Object.keys(itemDefinitions);

  if (itemIds.length > 6) {
    throw new Error("This interface has exactly six inventory windows. GAME.items can contain at most 6 items.");
  }

  /* ----------------------------------------------------------------------- */
  /* 4. ENGINE RUNTIME STATE                                                 */
  /* ----------------------------------------------------------------------- */

  let state = createFreshState();
  let currentHotspots = [];
  let musicEnabled = true;
  let activePrompt = null;

  // Adding ?debug=1 to the page address turns hotspot boxes on.
  // Example: index.html?debug=1
  const debugMode = new URLSearchParams(window.location.search).get("debug") === "1";

  // Hidden speedrun-style timer. It starts when START GAME / TRY AGAIN /
  // PLAY AGAIN starts a new run and stops the moment engine.win() is called.
  let runTimerStart = null;
  let runTimerEnd = null;

  /* ----------------------------------------------------------------------- */
  /* 5. CREATE / RESET STATE                                                 */
  /* ----------------------------------------------------------------------- */

  function createFreshState() {
    // Start every declared item as "not owned."
    const inventory = {};
    for (const id of itemIds) {
      inventory[id] = false;
    }

    // Let game.js add its own custom fields (usually state.flags).
    const customState = typeof game.createState === "function"
      ? clonePlainData(game.createState())
      : {};

    // Engine-owned fields come last so a game cannot accidentally start in an
    // impossible internal action state.
    return {
      ...customState,
      scene: game.startScene,
      verb: null,
      selectedItem: null,
      inventory: {
        ...inventory,
        ...(customState.inventory || {})
      },
      dead: false,
      won: false
    };
  }

  function clonePlainData(value) {
    // structuredClone is built into modern browsers. The JSON fallback keeps
    // this template usable in older browsers for ordinary numbers, strings,
    // booleans, arrays, and plain objects.
    if (typeof structuredClone === "function") {
      return structuredClone(value);
    }
    return JSON.parse(JSON.stringify(value));
  }

  /* ----------------------------------------------------------------------- */
  /* 6. CONTEXT OBJECT PASSED TO GAME HANDLERS                               */
  /* ----------------------------------------------------------------------- */

  function makeContext(extra = {}) {
    return {
      engine: Engine,
      state,
      sceneId: state.scene,
      scene: game.scenes[state.scene],
      selectedItem: state.selectedItem,
      ...extra
    };
  }

  /* ----------------------------------------------------------------------- */
  /* 7. TEXT / ACTION-SELECTION HELPERS                                      */
  /* ----------------------------------------------------------------------- */

  function say(text) {
    ui.message.textContent = text == null ? "" : String(text);
  }

  function setVerb(verb) {
    state.verb = verb;
    state.selectedItem = null;

    document.querySelectorAll(".verb").forEach(function (button) {
      button.classList.toggle("active", button.dataset.verb === verb);
    });

    updateActionStatus();
    renderInventory();
  }

  function clearAction() {
    setVerb(null);
  }

  function updateActionStatus() {
    let text = "Choose an action.";

    if (state.verb === "go") {
      text = "GO — choose a direction.";
    } else if (state.verb === "examine") {
      text = "EXAMINE — click something in the scene or inventory.";
    } else if (state.verb === "take") {
      text = "TAKE — click something in the scene.";
    } else if (state.verb === "operate") {
      if (state.selectedItem) {
        const item = itemDefinitions[state.selectedItem];
        const name = item ? item.name : state.selectedItem;
        text = `OPERATE THE ${String(name).toUpperCase()} ON?`;
      } else {
        text = "OPERATE — click an inventory item, then its target.";
      }
    }

    ui.actionStatus.textContent = text;
  }

  /* ----------------------------------------------------------------------- */
  /* 8. SCENE VALUES CAN BE STRINGS OR FUNCTIONS                             */
  /* ----------------------------------------------------------------------- */

  function resolveValue(value, extraContext = {}) {
    if (typeof value === "function") {
      return value(makeContext(extraContext));
    }
    return value;
  }

  function getCurrentScene() {
    const scene = game.scenes[state.scene];
    if (!scene) {
      throw new Error(`Scene "${state.scene}" does not exist in GAME.scenes.`);
    }
    return scene;
  }

  /* ----------------------------------------------------------------------- */
  /* 9. PLACEHOLDER ART                                                      */
  /* ----------------------------------------------------------------------- */

  // The raw engine ships without game artwork. If an image path is blank,
  // generate a neutral SVG so the scene window still has a useful 4:3 image.
  function placeholderImage(label, width = 640, height = 480) {
    const safeLabel = escapeXml(label || "SCENE IMAGE GOES HERE");
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
        <rect width="100%" height="100%" fill="#111"/>
        <rect x="18" y="18" width="${width - 36}" height="${height - 36}" fill="#222" stroke="#777" stroke-width="4"/>
        <text x="50%" y="47%" fill="#ddd" font-family="monospace" font-size="28" text-anchor="middle">${safeLabel}</text>
        <text x="50%" y="55%" fill="#888" font-family="monospace" font-size="18" text-anchor="middle">Replace the image path in js/game.js</text>
      </svg>`;

    return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }

  function escapeXml(text) {
    return String(text)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&apos;");
  }

  /* ----------------------------------------------------------------------- */
  /* 10. RENDER THE CURRENT SCENE                                            */
  /* ----------------------------------------------------------------------- */

  function renderScene() {
    const scene = getCurrentScene();
    const title = resolveValue(scene.title) || state.scene;
    const image = resolveValue(scene.image);
    const hotspots = resolveValue(scene.hotspots) || [];

    ui.sceneTitle.textContent = title;
    ui.sceneImage.alt = title;
    ui.sceneImage.src = image || placeholderImage(title);

    if (!Array.isArray(hotspots)) {
      throw new Error(`Scene "${state.scene}" hotspots must be an array or a function returning an array.`);
    }

    currentHotspots = hotspots;

    if (debugMode) {
      // renderDebug() also runs again after the image finishes loading.
      renderDebug();
    }
  }

  /* ----------------------------------------------------------------------- */
  /* 11. THE IMPORTANT HOTSPOT-SCALING FIX                                   */
  /* ----------------------------------------------------------------------- */

  // WHY THIS EXISTS:
  // CSS object-fit: contain can letterbox an image inside its <img> element.
  // The element's rectangle and the ACTUAL PAINTED PICTURE are therefore not
  // always the same rectangle. Using the element rectangle directly makes
  // hotspots drift on some screen sizes.
  //
  // This function calculates the rectangle occupied by the visible picture.
  function getVisibleSceneRect() {
    const box = ui.sceneImage.getBoundingClientRect();
    const imageWidth = ui.sceneImage.naturalWidth || box.width;
    const imageHeight = ui.sceneImage.naturalHeight || box.height;

    if (!imageWidth || !imageHeight || !box.width || !box.height) {
      return box;
    }

    const scale = Math.min(box.width / imageWidth, box.height / imageHeight);
    const width = imageWidth * scale;
    const height = imageHeight * scale;

    return {
      left: box.left + (box.width - width) / 2,
      top: box.top + (box.height - height) / 2,
      right: box.left + (box.width + width) / 2,
      bottom: box.top + (box.height + height) / 2,
      width,
      height
    };
  }

  /* ----------------------------------------------------------------------- */
  /* 12. DRAW HOTSPOTS IN DEBUG MODE                                         */
  /* ----------------------------------------------------------------------- */

  function renderDebug() {
    ui.debugOverlay.innerHTML = "";

    if (!debugMode) {
      return;
    }

    const imageRect = getVisibleSceneRect();
    const wrapRect = ui.sceneWrap.getBoundingClientRect();

    for (const hotspot of currentHotspots) {
      const box = document.createElement("div");
      box.className = "debug-hotspot";
      box.textContent = hotspot.id || "hotspot";

      box.style.left = `${(imageRect.left - wrapRect.left) + (hotspot.x / 100) * imageRect.width}px`;
      box.style.top = `${(imageRect.top - wrapRect.top) + (hotspot.y / 100) * imageRect.height}px`;
      box.style.width = `${(hotspot.w / 100) * imageRect.width}px`;
      box.style.height = `${(hotspot.h / 100) * imageRect.height}px`;

      ui.debugOverlay.appendChild(box);
    }
  }

  /* ----------------------------------------------------------------------- */
  /* 13. SCENE CLICK -> HOTSPOT                                              */
  /* ----------------------------------------------------------------------- */

  function sceneClick(event) {
    if (state.dead || state.won) {
      return;
    }

    if (!state.verb || state.verb === "go") {
      say(state.verb === "go" ? "Choose a direction button." : "Choose an action first.");
      return;
    }

    const rect = getVisibleSceneRect();

    // A click in the black letterbox area is not a click on the picture.
    if (
      event.clientX < rect.left ||
      event.clientX > rect.right ||
      event.clientY < rect.top ||
      event.clientY > rect.bottom
    ) {
      clearAction();
      return;
    }

    const xPercent = ((event.clientX - rect.left) / rect.width) * 100;
    const yPercent = ((event.clientY - rect.top) / rect.height) * 100;

    // Search backwards. If two hotspots overlap, the one defined later in the
    // scene's array wins. This is useful for putting a small sign on a large
    // wall hotspot, for example.
    const hotspot = [...currentHotspots].reverse().find(function (candidate) {
      return (
        xPercent >= candidate.x &&
        xPercent <= candidate.x + candidate.w &&
        yPercent >= candidate.y &&
        yPercent <= candidate.y + candidate.h
      );
    });

    if (!hotspot) {
      if (state.verb === "examine") say("Nothing unusual here.");
      if (state.verb === "take") say("You can't take that.");
      if (state.verb === "operate") say("You can't operate that.");
      clearAction();
      return;
    }

    let result = "";
    const context = makeContext({ hotspot, itemId: state.selectedItem });

    if (state.verb === "examine") {
      result = hotspot.examine
        ? resolveHandler(hotspot.examine, context)
        : "Nothing unusual here.";
    } else if (state.verb === "take") {
      result = hotspot.take
        ? resolveHandler(hotspot.take, context)
        : "You can't take that.";
    } else if (state.verb === "operate") {
      result = hotspot.operate
        ? resolveHandler(hotspot.operate, context)
        : "You can't operate that.";
    }

    if (result) {
      say(result);
    }

    if (!state.dead && !state.won) {
      clearAction();
    }
  }

  function resolveHandler(handler, context) {
    return typeof handler === "function" ? handler(context) : handler;
  }

  /* ----------------------------------------------------------------------- */
  /* 14. DIRECTION BUTTONS                                                   */
  /* ----------------------------------------------------------------------- */

  function directionClick(direction) {
    if (state.verb !== "go") {
      say("Click GO first, then choose a direction.");
      return;
    }

    const scene = getCurrentScene();
    const exit = scene.exits ? scene.exits[direction] : null;

    if (!exit) {
      say("You can't go that way.");
      clearAction();
      return;
    }

    if (typeof exit === "string") {
      goTo(exit);
      return;
    }

    if (typeof exit === "function") {
      const result = exit(makeContext({ direction }));
      if (result) say(result);
      if (!state.dead && !state.won && state.verb === "go") clearAction();
      return;
    }

    throw new Error(`Exit ${direction} in scene "${state.scene}" must be a scene ID string or a function.`);
  }

  /* ----------------------------------------------------------------------- */
  /* 15. CHANGE SCENES                                                       */
  /* ----------------------------------------------------------------------- */

  function goTo(sceneId, message) {
    if (!game.scenes[sceneId]) {
      throw new Error(`Cannot go to "${sceneId}" because that scene does not exist.`);
    }

    state.scene = sceneId;
    clearAction();
    renderScene();

    const scene = getCurrentScene();
    const defaultDescription = resolveValue(scene.description) || "";
    say(message !== undefined ? message : defaultDescription);
  }

  /* ----------------------------------------------------------------------- */
  /* 16. SIX-SLOT INVENTORY                                                  */
  /* ----------------------------------------------------------------------- */

  function renderInventory() {
    ui.inventory.innerHTML = "";

    // Always draw exactly six windows, even if the game has fewer than six
    // possible inventory items. This preserves the V50 UI layout.
    for (let slotIndex = 0; slotIndex < 6; slotIndex += 1) {
      const id = itemIds[slotIndex];
      const owned = id ? Boolean(state.inventory[id]) : false;
      const item = id ? itemDefinitions[id] : null;

      const slot = document.createElement("button");
      slot.className = "item-slot";
      slot.disabled = !owned;

      if (id) {
        slot.dataset.item = id;
      }

      if (owned && item) {
        slot.classList.add("owned");

        if (state.selectedItem === id) {
          slot.classList.add("selected");
        }

        if (item.icon) {
          const icon = document.createElement("img");
          icon.className = "item-icon";
          icon.src = resolveValue(item.icon, { itemId: id });
          icon.alt = "";
          slot.appendChild(icon);
        }

        const label = document.createElement("span");
        label.className = "item-label";
        label.textContent = item.name || id;
        slot.appendChild(label);

        slot.addEventListener("click", function () {
          inventoryClick(id);
        });
      } else {
        // Intentionally EMPTY. No silhouette, blur, label, or hint.
        slot.setAttribute("aria-label", "Empty inventory slot");
      }

      ui.inventory.appendChild(slot);
    }
  }

  function inventoryClick(id) {
    if (!state.inventory[id]) {
      return;
    }

    const item = itemDefinitions[id];

    if (state.verb === "examine") {
      const result = item && item.examine
        ? resolveHandler(item.examine, makeContext({ itemId: id }))
        : `This is the ${item ? item.name : id}.`;

      if (result) say(result);
      clearAction();
      return;
    }

    if (state.verb === "operate") {
      // If one inventory item is already selected, this click is an attempt to
      // use one inventory item on another inventory item.
      if (state.selectedItem) {
        const result = runItemCombination(state.selectedItem, id);
        say(result || "Nothing happened.");
        clearAction();
        renderInventory();
        return;
      }

      // Otherwise, this is the first half of "OPERATE ITEM ON ..."
      state.selectedItem = id;
      renderInventory();
      updateActionStatus();
      return;
    }

    say("Select EXAMINE or OPERATE first.");
  }

  function runItemCombination(firstId, secondId) {
    const combinations = game.itemCombinations || [];

    const match = combinations.find(function (combination) {
      if (!Array.isArray(combination.items) || combination.items.length !== 2) {
        return false;
      }

      const [a, b] = combination.items;
      return (
        (a === firstId && b === secondId) ||
        (a === secondId && b === firstId)
      );
    });

    if (!match) {
      return "Nothing happened.";
    }

    return resolveHandler(match.action, makeContext({
      firstItemId: firstId,
      secondItemId: secondId
    }));
  }

  function takeItem(id, message) {
    if (!itemDefinitions[id]) {
      throw new Error(`Cannot take unknown item "${id}". Add it to GAME.items first.`);
    }

    if (state.inventory[id]) {
      return "You already have that!";
    }

    state.inventory[id] = true;
    renderInventory();

    return message || `You took the ${itemDefinitions[id].name || id}.`;
  }

  function removeItem(id) {
    if (Object.prototype.hasOwnProperty.call(state.inventory, id)) {
      state.inventory[id] = false;
      if (state.selectedItem === id) state.selectedItem = null;
      renderInventory();
      updateActionStatus();
    }
  }

  function hasItem(id) {
    return Boolean(state.inventory[id]);
  }

  /* ----------------------------------------------------------------------- */
  /* 17. GAME OVER / VICTORY                                                 */
  /* ----------------------------------------------------------------------- */

  function die(message) {
    state.dead = true;
    pauseMusic();

    ui.gameScreen.classList.add("hidden");
    ui.gameOverScreen.classList.remove("hidden");
    ui.deathMessage.textContent = message || "Game over.";
  }

  function win(message) {
    if (state.won) return;

    state.won = true;
    stopRunTimer();
    pauseMusic();

    ui.gameScreen.classList.add("hidden");
    ui.winScreen.classList.remove("hidden");

    if (message) {
      ui.winHeading.textContent = message;
    } else {
      ui.winHeading.textContent = game.winHeading || "You won!";
    }

    ui.escapeTime.textContent = `ESCAPE TIME: ${formatRunTime()}`;

    if (game.victorySound) {
      ui.victorySound.currentTime = 0;
      ui.victorySound.play().catch(function () {});
    }
  }

  /* ----------------------------------------------------------------------- */
  /* 18. HIDDEN RUN TIMER                                                    */
  /* ----------------------------------------------------------------------- */

  function startRunTimer() {
    runTimerStart = performance.now();
    runTimerEnd = null;
    ui.escapeTime.textContent = "";
  }

  function stopRunTimer() {
    if (runTimerStart !== null && runTimerEnd === null) {
      runTimerEnd = performance.now();
    }
  }

  function formatRunTime() {
    const end = runTimerEnd ?? performance.now();
    const elapsed = Math.max(0, Math.floor(end - (runTimerStart ?? end)));

    const milliseconds = elapsed % 1000;
    const totalSeconds = Math.floor(elapsed / 1000);
    const seconds = totalSeconds % 60;
    const totalMinutes = Math.floor(totalSeconds / 60);
    const minutes = totalMinutes % 60;
    const hours = Math.floor(totalMinutes / 60);

    return `${String(hours).padStart(2, "0")} Hours ` +
           `${String(minutes).padStart(2, "0")} Minutes ` +
           `${String(seconds).padStart(2, "0")} Seconds ` +
           `${String(milliseconds).padStart(3, "0")} Milliseconds`;
  }

  /* ----------------------------------------------------------------------- */
  /* 19. GENERIC TEXT PROMPT                                                 */
  /* ----------------------------------------------------------------------- */

  // Use this for passwords, computer terminals, keypad codes, riddles, names,
  // or any other place where the player must type text.
  //
  // Example from game.js:
  //
  // engine.openTextPrompt({
  //   body: "SECURITY TERMINAL\\n\\nPassword:",
  //   onSubmit(value) {
  //     return value === "1234" ? "ACCESS GRANTED" : "ACCESS DENIED";
  //   }
  // });
  function openTextPrompt(options = {}) {
    activePrompt = options;
    ui.promptBody.textContent = options.body || "Enter text:";
    ui.promptInput.value = options.value || "";
    ui.promptInput.placeholder = options.placeholder || "";
    ui.promptModal.classList.remove("hidden");

    // Delay focus one frame so mobile/desktop browsers see the now-visible box.
    requestAnimationFrame(function () {
      ui.promptInput.focus();
      if (options.selectText) ui.promptInput.select();
    });
  }

  function closeTextPrompt() {
    ui.promptModal.classList.add("hidden");
    activePrompt = null;
  }

  function submitTextPrompt() {
    if (!activePrompt) return;

    const options = activePrompt;
    const value = ui.promptInput.value;

    let result = "";
    if (typeof options.onSubmit === "function") {
      result = options.onSubmit(value, makeContext({ value }));
    }

    closeTextPrompt();
    if (result) say(result);
    clearAction();
  }

  function cancelTextPrompt() {
    const options = activePrompt;
    closeTextPrompt();

    if (options && typeof options.onCancel === "function") {
      const result = options.onCancel(makeContext());
      if (result) say(result);
    }

    clearAction();
  }

  /* ----------------------------------------------------------------------- */
  /* 20. AUDIO                                                               */
  /* ----------------------------------------------------------------------- */

  function configureAudio() {
    if (game.music) ui.music.src = game.music;
    if (game.victorySound) ui.victorySound.src = game.victorySound;

    ui.music.volume = Number.isFinite(game.musicVolume) ? game.musicVolume : 0.30;
    updateMusicButton();
  }

  function playMusic() {
    if (!musicEnabled || !game.music) return;
    ui.music.play().catch(function () {
      // Browsers may block autoplay until the player interacts with the page.
      // START GAME is a user click, so this usually succeeds.
    });
  }

  function pauseMusic() {
    ui.music.pause();
  }

  function toggleMusic() {
    musicEnabled = !musicEnabled;
    updateMusicButton();

    if (musicEnabled && !state.dead && !state.won) {
      playMusic();
    } else {
      pauseMusic();
    }
  }

  function updateMusicButton() {
    ui.musicButton.textContent = musicEnabled ? "MUSIC: ON" : "MUSIC: OFF";
  }

  /* ----------------------------------------------------------------------- */
  /* 21. START / RESTART / EXIT                                              */
  /* ----------------------------------------------------------------------- */

  function newGame() {
    state = createFreshState();
    startRunTimer();

    ui.startScreen.classList.add("hidden");
    ui.gameOverScreen.classList.add("hidden");
    ui.winScreen.classList.add("hidden");
    ui.gameScreen.classList.remove("hidden");

    renderScene();
    renderInventory();
    updateActionStatus();

    const scene = getCurrentScene();
    say(resolveValue(scene.description) || "");

    ui.music.currentTime = 0;
    playMusic();
  }

  function showStart() {
    ui.gameScreen.classList.add("hidden");
    ui.gameOverScreen.classList.add("hidden");
    ui.winScreen.classList.add("hidden");
    ui.startScreen.classList.remove("hidden");
    pauseMusic();
    clearAction();
  }

  /* ----------------------------------------------------------------------- */
  /* 22. HOTSPOT COORDINATE HELPER                                           */
  /* ----------------------------------------------------------------------- */

  // If you measured a hotspot in IMAGE PIXELS, this helper converts it to the
  // percentages the engine stores.
  //
  // Example for a 640x480 picture:
  //   engine.rectFromPixels(640, 480, 100, 50, 220, 180, {
  //     id: "door",
  //     examine: "A wooden door."
  //   })
  //
  // x1/y1 = upper-left corner in source-image pixels
  // x2/y2 = lower-right corner in source-image pixels
  function rectFromPixels(imageWidth, imageHeight, x1, y1, x2, y2, extra = {}) {
    return {
      ...extra,
      x: (x1 / imageWidth) * 100,
      y: (y1 / imageHeight) * 100,
      w: ((x2 - x1) / imageWidth) * 100,
      h: ((y2 - y1) / imageHeight) * 100
    };
  }

  /* ----------------------------------------------------------------------- */
  /* 23. PUBLIC ENGINE API                                                   */
  /* ----------------------------------------------------------------------- */

  // Game handlers receive this same object as context.engine.
  const Engine = {
    say,
    goTo,
    takeItem,
    removeItem,
    hasItem,
    die,
    win,
    renderScene,
    renderInventory,
    clearAction,
    openTextPrompt,
    closeTextPrompt,
    rectFromPixels,

    // getState() intentionally returns the live state object. This keeps puzzle
    // code beginner-friendly:
    //
    //   engine.getState().flags.doorOpen = true;
    //
    // For a larger commercial project you might choose stricter encapsulation.
    getState() {
      return state;
    },

    getGame() {
      return game;
    },

    isDebugMode() {
      return debugMode;
    }
  };

  // Also expose it globally so you can experiment in the browser console.
  window.Engine = Engine;

  /* ----------------------------------------------------------------------- */
  /* 24. PUT GAME METADATA INTO THE UI                                       */
  /* ----------------------------------------------------------------------- */

  function configureUiFromGame() {
    document.title = game.title || "Point & Click Adventure";

    ui.startNote1.textContent = (game.startNotes && game.startNotes[0]) || "";
    ui.startNote2.textContent = (game.startNotes && game.startNotes[1]) || "";
    ui.buildLabel.textContent = game.buildLabel || "";

    ui.instructionsContent.innerHTML = game.instructionsHtml || "";
    ui.storyContent.innerHTML = game.storyHtml || "";
    ui.aboutContent.innerHTML = game.aboutHtml || "";

    ui.winHeading.textContent = game.winHeading || "You won!";
    ui.winSubtitle.textContent = game.winSubtitle || "PRESS PLAY AGAIN TO START OVER";

    ui.titleArt.src = game.titleImage || placeholderImage(game.title || "YOUR GAME TITLE", 800, 450);
    ui.gameOverImage.src = game.gameOverImage || placeholderImage("GAME OVER", 640, 360);
    ui.winImage.src = game.winImage || placeholderImage("VICTORY", 640, 360);
  }

  /* ----------------------------------------------------------------------- */
  /* 25. EVENT LISTENERS                                                     */
  /* ----------------------------------------------------------------------- */

  ui.sceneImage.addEventListener("click", sceneClick);
  ui.sceneImage.addEventListener("load", function () {
    if (debugMode) renderDebug();
  });

  window.addEventListener("resize", function () {
    if (debugMode) renderDebug();
  });

  document.querySelectorAll(".verb").forEach(function (button) {
    button.addEventListener("click", function () {
      setVerb(button.dataset.verb);
    });
  });

  document.querySelectorAll(".dir").forEach(function (button) {
    button.addEventListener("click", function () {
      directionClick(button.dataset.dir);
    });
  });

  $("#start-btn").addEventListener("click", newGame);
  $("#restart-btn").addEventListener("click", newGame);
  $("#restart-win-btn").addEventListener("click", newGame);
  $("#quit-btn").addEventListener("click", showStart);
  ui.musicButton.addEventListener("click", toggleMusic);

  $("#instructions-btn").addEventListener("click", function () {
    ui.helpModal.classList.remove("hidden");
  });
  $("#story-btn").addEventListener("click", function () {
    ui.storyModal.classList.remove("hidden");
  });
  $("#about-btn").addEventListener("click", function () {
    ui.aboutModal.classList.remove("hidden");
  });
  $("#help-close").addEventListener("click", function () {
    ui.helpModal.classList.add("hidden");
  });
  $("#story-close").addEventListener("click", function () {
    ui.storyModal.classList.add("hidden");
  });
  $("#about-close").addEventListener("click", function () {
    ui.aboutModal.classList.add("hidden");
  });

  ui.promptSubmit.addEventListener("click", submitTextPrompt);
  ui.promptCancel.addEventListener("click", cancelTextPrompt);
  ui.promptInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") submitTextPrompt();
    if (event.key === "Escape") cancelTextPrompt();
  });

  /* ----------------------------------------------------------------------- */
  /* 26. BOOT THE ENGINE                                                     */
  /* ----------------------------------------------------------------------- */

  configureUiFromGame();
  configureAudio();
  renderInventory();
  updateActionStatus();
})();
