"use strict";

/*
===============================================================================
GAME.JS — THIS IS THE FILE A BEGINNER SHOULD EDIT FIRST
===============================================================================

The engine itself lives in engine.js.
This file is deliberately separate so your GAME CONTENT does not get tangled
up with the ENGINE CODE.

Think of it like this:

    engine.js = the rules of a board game
    game.js   = the board, rooms, objects, dialogue, puzzles, and story

The starter below contains only one neutral blank scene so the engine can be
opened immediately in a browser. It is not a real game and contains no content
from Escape From Dinosaur Island.

Read README.md before changing anything. The comments in this file are the
short version.
===============================================================================
*/

window.GAME = {
  /* ----------------------------------------------------------------------- */
  /* BASIC INFORMATION                                                       */
  /* ----------------------------------------------------------------------- */

  title: "Untitled Point & Click Adventure",

  // Small text in the lower-right corner while the game is running.
  buildLabel: "RAW ENGINE TEMPLATE",

  // The first scene shown after START GAME is pressed.
  startScene: "start",

  // These two lines appear under the title-screen buttons.
  startNotes: [
    "Classic point-and-click adventure engine.",
    "Edit js/game.js to build your own game."
  ],

  /* ----------------------------------------------------------------------- */
  /* TITLE / END SCREEN IMAGES                                                */
  /* ----------------------------------------------------------------------- */

  // Leave these as empty strings and the engine will generate neutral
  // placeholders. Or replace them with paths such as:
  //   "assets/title.png"
  //   "assets/game-over.png"
  //   "assets/win.png"
  titleImage: "",
  gameOverImage: "",
  winImage: "",

  /* ----------------------------------------------------------------------- */
  /* AUDIO                                                                    */
  /* ----------------------------------------------------------------------- */

  // Paths can point to OGG, MP3, WAV, etc. Leave blank for silence.
  music: "",
  victorySound: "",
  musicVolume: 0.30,

  /* ----------------------------------------------------------------------- */
  /* START-SCREEN TEXT                                                        */
  /* ----------------------------------------------------------------------- */

  storyHtml: `
    <p>This is a blank engine template.</p>
    <p>Replace this text with your game's story in <b>js/game.js</b>.</p>
  `,

  aboutHtml: `
    <p>Classic Point & Click Adventure Engine.</p>
    <p>The engine and game data are intentionally separated for readability.</p>
  `,

  // You may replace this with your own instructions, but these defaults match
  // the four-button interface used by the engine.
  instructionsHtml: `
    <p>To move between scenes, first click <b>GO</b>, then click a direction.</p>
    <p>To use an action—<b>TAKE</b>, <b>OPERATE</b>, <b>GO</b>, or <b>EXAMINE</b>—click the appropriate button first.</p>
    <p>Then click the object you want to use it on. You must choose the action again each time you perform one.</p>
    <p>For example, you cannot click <b>EXAMINE</b> once and then inspect several objects; click <b>EXAMINE</b> before each object.</p>
  `,

  /* ----------------------------------------------------------------------- */
  /* INVENTORY                                                                */
  /* ----------------------------------------------------------------------- */

  // The interface always has SIX inventory windows, exactly like V50.
  // Add up to six item definitions here. Empty positions stay blank.
  //
  // Example item (remove the // marks if you want to experiment):
  //
  // key: {
  //   name: "Key",
  //   icon: "assets/items/key.png",
  //   examine: "A small brass key."
  // }
  //
  // An item's ID (such as "key") is how the code refers to it internally.
  items: {
  },

  /* ----------------------------------------------------------------------- */
  /* OPTIONAL ITEM-ON-ITEM COMBINATIONS                                      */
  /* ----------------------------------------------------------------------- */

  // This is where you define things such as MATCHES + TORCH.
  // Order does not matter: ["a", "b"] also matches using b on a.
  //
  // itemCombinations: [
  //   {
  //     items: ["matches", "torch"],
  //     action({ engine, state }) {
  //       state.flags.torchLit = true;
  //       return "You light the torch.";
  //     }
  //   }
  // ],
  itemCombinations: [],

  /* ----------------------------------------------------------------------- */
  /* EXTRA GAME STATE                                                         */
  /* ----------------------------------------------------------------------- */

  // The engine automatically tracks:
  //   state.scene
  //   state.verb
  //   state.selectedItem
  //   state.inventory
  //   state.dead
  //   state.won
  //
  // Put your own puzzle flags under state.flags. Keeping custom flags together
  // makes a game much easier to understand later.
  createState() {
    return {
      flags: {
        // Example:
        // doorOpen: false,
        // powerOn: true,
      }
    };
  },

  /* ----------------------------------------------------------------------- */
  /* SCENES                                                                   */
  /* ----------------------------------------------------------------------- */

  // Every scene is one entry in this object.
  //
  // A scene can contain:
  //   title       - text shown above the scene
  //   image       - image path OR a function returning an image path
  //   description - text shown when entering the scene
  //   exits       - north/east/south/west destinations
  //   hotspots    - clickable rectangles inside the scene picture
  //
  // For a normal exit, simply put the destination scene ID as a string:
  //     north: "hallway"
  //
  // For a conditional exit, use a function and call engine.goTo(), engine.die(),
  // etc. See README.md for several complete examples.
  scenes: {
    start: {
      title: "Starter Scene",

      // An empty image tells the engine to draw a neutral placeholder.
      // Replace with something like "assets/scenes/start.png".
      image: "",

      description: "This is the blank starter scene. Add your game in js/game.js.",

      exits: {
        // north: "anotherScene",
        // east: "anotherScene",
        // south: "anotherScene",
        // west: "anotherScene",
      },

      // No hotspots yet. See the examples in README.md.
      hotspots: []
    }
  },

  /* ----------------------------------------------------------------------- */
  /* END-SCREEN WORDING                                                       */
  /* ----------------------------------------------------------------------- */

  winHeading: "You won!",
  winSubtitle: "PRESS PLAY AGAIN TO START OVER"
};
